﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HospitalManagementSystem
{
    public class HMSException : ApplicationException
    {
        public HMSException(string Message) : base(Message)
        { }
    }
}
