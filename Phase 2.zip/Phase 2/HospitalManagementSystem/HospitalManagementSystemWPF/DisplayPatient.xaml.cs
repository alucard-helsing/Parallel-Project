﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HospitalManagementSystemWPF
{
    /// <summary>
    /// Interaction logic for DisplayPatient.xaml
    /// </summary>
    public partial class DisplayPatient : Window
    {
        public DisplayPatient()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow obj = new MainWindow();
            obj.Show();
            this.Hide();
        }
        private void LoadPIDs()
        {
            List<string> listofids = PatientBLL.PatientBLL.GetPIDs();
            cboId.ItemsSource = listofids;
            cboId.Text = "select";
        }
        private void CboId_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string pId = cboId.SelectedValue.ToString();
            
            try
            {
                DataSet dsobj = PatientBLL.PatientBLL.DisplayPatientByIdBL(pId);
                dgPatient.DataContext = dsobj.Tables["Patient"];
            }
            catch (HospitalManagementSystem.HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        //
        
        //
        private void RefreshPatients()
        {
            DataTable dtPatient = PatientBLL.PatientBLL.DisplayPatient();
            if (dtPatient.Rows.Count > 0)
            {
                dgPatient.DataContext = dtPatient;
            }
            else
                MessageBox.Show("Data not available");
        }
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadPIDs();
            RefreshPatients();
        }

        

        private void btnShowAll_Click(object sender, RoutedEventArgs e)
        {
            RefreshPatients();
        }

        //delete
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string pId = cboId.Text;
            try
            {
                MessageBoxResult result = MessageBox.Show("Do you want to delete the patient's record?", "Hospital Management", MessageBoxButton.YesNo, MessageBoxImage.Question);
                if (result == MessageBoxResult.Yes)
                {
                    int count = PatientBLL.PatientBLL.DeletePatientBL(pId);
                    if (count > 0)
                    {
                        MessageBox.Show("Patient Record is deleted successfully...");
                        RefreshPatients();
                        // Window_Loaded(sender, e);
                    }
                }
                else
                    MessageBox.Show("Patient Record is not deleted..Try Again..!");
            }
            catch (HospitalManagementSystem.HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       //backup
        private void btnBackup_Click(object sender, RoutedEventArgs e)
        {
            if (cboId.SelectionBoxItem.ToString() != "Select")
            {
                string pId = cboId.SelectionBoxItem.ToString();
                

                DataSet dsObj = PatientBLL.PatientBLL.DisplayPatientByIdBL(pId);
                if (!Directory.Exists(@"D:\mydata\"))
                    Directory.CreateDirectory(@"D:\mydata\");

                dsObj.WriteXml(@"D:\mydata.xml");
                MessageBox.Show("Patient Details are backedup..!");
            }

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
