﻿using HospitalManagementSystem;
using PatientEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HospitalManagementSystemWPF
{
    /// <summary>
    /// Interaction logic for MedicalBills.xaml
    /// </summary>
    public partial class MedicalBills : Window
    {
        public MedicalBills()
        {
            InitializeComponent();
        }

        private void Btnsave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient newPatient = new Patient();
                newPatient.BillNo = int.Parse(txtbillno.Text);
                newPatient.PatientId = txtpatientid.Text;
                newPatient.PatientType = txtpatientid.Text;
                newPatient.DoctorId = int.Parse(txtdoctorid.Text);
                newPatient.DoctorFees = int.Parse(txtdoctorfees.Text);
                newPatient.Roomcharge = int.Parse(txtroomcharge.Text);
                newPatient.Operationcharges = int.Parse(txtoperationcharges.Text);
                newPatient.Medicinefees = int.Parse(txtmedicinefees.Text);
                newPatient.Totaldays = int.Parse(txttotaldays.Text);
                newPatient.Labfees = int.Parse(txtlabfees.Text);
                //newPatient.Amount = int.Parse(txtamount.Text);
                int patientInserted = PatientBLL.PatientBLL.AddBill(newPatient);
                if (patientInserted > 0)
                {
                    MessageBox.Show("Patient Record Inserted Successfully");

                }
                else
                    throw new HMSException
                        ("Patient record not inserted");

            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow obj = new MainWindow();
            obj.Show();
            this.Hide();
        }
    }
}
