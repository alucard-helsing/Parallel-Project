﻿using HospitalManagementSystem;
using PatientBLL;
using PatientEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HospitalManagementSystemWPF
{
    /// <summary>
    /// Interaction logic for AddPatient.xaml
    /// </summary>
    public partial class AddPatient : Window
    {
        public AddPatient()
        {
            InitializeComponent();
        }



        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow Obj = new MainWindow();
            Obj.Show();
            this.Hide();

        }
        
        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient newPatient = new Patient();
                newPatient.PatientId = txtpatientId.Text;
                newPatient.PatientName = txtpatientName.Text;
                newPatient.Contact = txtContact.Text;
                newPatient.PatientGender = cboGender.SelectionBoxItem.ToString();
                newPatient.PatientAddress = txtAddress.Text;
                newPatient.PatientWeight = int.Parse(txtWeight.Text);
                newPatient.Disease = txtDisease.Text;
                newPatient.DoctorId = int.Parse(txtDoctorId.Text);
                newPatient.PatientAge = int.Parse(txtAge.Text);
                int patientInserted = PatientBLL.PatientBLL.AddPatientBL(newPatient);
                if (patientInserted > 0)
                {
                    MessageBox.Show("Patient Record Inserted Successfully");

                }
                else
                    throw new HMSException
                        ("Patient record not inserted");

            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnUpdate_Click_1(object sender, RoutedEventArgs e)
        {
            Patient newPatient = new Patient();
            try
            {
                newPatient.PatientId = txtpatientId.Text;
                newPatient.PatientName = txtpatientName.Text;
                newPatient.Contact = txtContact.Text;
                newPatient.DoctorId = int.Parse(txtDoctorId.Text);
                newPatient.Disease = txtDisease.Text;
                newPatient.PatientAddress = txtAddress.Text;
                newPatient.PatientAge = int.Parse(txtAge.Text);
                newPatient.PatientWeight = int.Parse(txtWeight.Text);
                newPatient.PatientGender = cboGender.SelectedValue.ToString();

                int patientUpdated = PatientBLL.PatientBLL.UpdatePatientBL(newPatient);
                if (patientUpdated > 0)
                {
                    MessageBox.Show("Patient Record is updated..!");
                    //Clear();
                }
                else
                    throw new HMSException("Patient record not updated..!");
            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow obj = new MainWindow();
            obj.Show();
            this.Hide();
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            //SET CONNECTION STRING
            string conString = "Data Source=DESKTOP-92E98T7;Initial Catalog=HospitalNewDB;Integrated Security=True";

            //CREATE CONNECTION OBJECT
            SqlConnection conObj = new SqlConnection(conString);

            //SEARCHING THE CUSTOMER USING PROCEDURE
            string searchQuery = "prc_GetPatientById";
            
           
            //OPEN THE CONNECTION
            conObj.Open();

            SqlCommand cmdObj = new SqlCommand(searchQuery, conObj);


            cmdObj.CommandType = CommandType.StoredProcedure;
            cmdObj.Parameters.AddWithValue("@pid", Convert.ToInt32(txtpatientId.Text));

            SqlDataReader dr;
            dr = cmdObj.ExecuteReader();
            if (dr.Read())
            {
                txtpatientName.Text = dr["PatientName"].ToString();
                txtAddress.Text = dr["PatientAddress"].ToString();
                txtAge.Text = dr["PatientAge"].ToString();
                txtContact.Text = dr["Contact"].ToString();
                txtWeight.Text = dr["PatientWeight"].ToString();
                txtDisease.Text = dr["Disease"].ToString();
                txtDoctorId.Text = dr["DoctorId"].ToString();
                cboGender.Text = dr["PatientGender"].ToString();
                
            }
            else
            {
                MessageBox.Show("Patient Not Found!");
            }
            conObj.Close();

        }
    }
}

