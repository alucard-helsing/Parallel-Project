﻿using HospitalManagementSystem;
using PatientEntity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HospitalManagementSystemWPF
{
    /// <summary>
    /// Interaction logic for Add_Lab_Report.xaml
    /// </summary>
    public partial class Add_Lab_Report : Window
    {
        public Add_Lab_Report()
        {
            InitializeComponent();
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient newPatient = new Patient();
                //newPatient.ReportId = txtId.Text;
                newPatient.PatientName = txtPatientName.Text;
                newPatient.Testdate = Convert.ToDateTime(txtdate.ToString());
                newPatient.DoctorName = txtDocName.Text;
                newPatient.Testtype = txtTesttype.Text;
                newPatient.Remarks = txtRemarks.Text;                
                int reportAdded = PatientBLL.PatientBLL.AddLabReportBL(newPatient);
                if (reportAdded > 0)
                {
                    MessageBox.Show("Lab Record Inserted Successfully");

                }
                else
                    throw new HMSException
                        ("Lab record not inserted");

            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow obj = new MainWindow();
            obj.Show();
            this.Hide();
        }
    }
}
