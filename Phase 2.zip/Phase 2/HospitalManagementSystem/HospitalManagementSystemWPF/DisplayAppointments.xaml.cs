﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HospitalManagementSystemWPF
{
    /// <summary>
    /// Interaction logic for DisplayAppointments.xaml
    /// </summary>
    public partial class DisplayAppointments : Window
    {
        public DisplayAppointments()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            RefreshPatients();
        }
        private void RefreshPatients()
        {
            DataTable dtAppointment = PatientBLL.PatientBLL.DisplayAppointment();
            if (dtAppointment.Rows.Count > 0)
            {
                dgAppointment.DataContext = dtAppointment;
            }
            else
                MessageBox.Show("Data not available");
        }

        private void BtnBack_Click(object sender, RoutedEventArgs e)
        {
            MainWindow obj = new MainWindow();
            obj.Show();
            this.Hide();
        }
    }
}
