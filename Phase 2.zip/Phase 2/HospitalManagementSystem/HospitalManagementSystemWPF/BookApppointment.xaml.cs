﻿using HospitalManagementSystem;
using PatientEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace HospitalManagementSystemWPF
{
    /// <summary>
    /// Interaction logic for BookApppointment.xaml
    /// </summary>
    public partial class BookApppointment : Window
    {
        public BookApppointment()
        {
            InitializeComponent();
        }

        private void BtnGetDetails_Click(object sender, RoutedEventArgs e)
        {
            //SET CONNECTION STRING
            string conString = "Data Source=DESKTOP-92E98T7;Initial Catalog=HospitalNewDB;Integrated Security=True";

            //CREATE CONNECTION OBJECT
            SqlConnection conObj = new SqlConnection(conString);

            //SEARCHING THE CUSTOMER USING PROCEDURE
            string searchQuery = "prc_GetPatientById";


            //OPEN THE CONNECTION
            conObj.Open();

            SqlCommand cmdObj = new SqlCommand(searchQuery, conObj);


            cmdObj.CommandType = CommandType.StoredProcedure;
            cmdObj.Parameters.AddWithValue("@pid", Convert.ToInt32(txtpatientId.Text));

            SqlDataReader dr;
            dr = cmdObj.ExecuteReader();
            if (dr.Read())
            {
                txtpatientName.Text = dr["PatientName"].ToString();
                txtAddress.Text = dr["PatientAddress"].ToString();
                txtAge.Text = dr["PatientAge"].ToString();
                txtContact.Text = dr["Contact"].ToString();
                txtWeight.Text = dr["PatientWeight"].ToString();
                txtDisease.Text = dr["Disease"].ToString();
                //txtDoctorName.Text = dr["DoctorName"].ToString();
                //cboGender.Text = dr["PatientGender"].ToString();

            }
            else
            {
                MessageBox.Show("Patient Not Found!");
            }
            conObj.Close();
        }

        private void BtnBook_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient newPatient = new Patient();
                newPatient.PatientId = txtpatientId.Text;
                newPatient.AppointmentId = txtAppointmentId.Text;
                newPatient.PatientName = txtpatientName.Text;
                newPatient.Contact = txtContact.Text;
                newPatient.PatientGender = cboGender.SelectionBoxItem.ToString();
                newPatient.Date = DateTime.Parse(txtDate.Text);
                newPatient.PatientAddress = txtAddress.Text;
                newPatient.PatientWeight = int.Parse(txtWeight.Text);
                newPatient.Disease = txtDisease.Text;
                newPatient.DoctorName = txtDoctorName.Text;
                newPatient.PatientAge = int.Parse(txtAge.Text);
                newPatient.Remarks = txtRemarks.Text;
                int appointmentBooked = PatientBLL.PatientBLL.BookAppointmentBL(newPatient);
                if (appointmentBooked > 0){

                MessageBox.Show("Patient Record Inserted Successfully");
                }

                else
                    throw new HMSException
                        ("Patient record not inserted");

            }
            catch (HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnAppointments_Click(object sender, RoutedEventArgs e)
        {
            DisplayAppointments displayApp = new DisplayAppointments();
            displayApp.Show();
            this.Hide();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MainWindow obj = new MainWindow();
            obj.Show();
            this.Hide();
        }
               
    }
}
