﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PatientEntity;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace PatientDAL
{
    public class PatientDAL
    {
        public static SqlCommand CreateCommand()
        {
            SqlCommand cmd = null;
            try
            {
                SqlConnection con = new SqlConnection();
                con.ConnectionString = "Data Source=DESKTOP-92E98T7;Initial Catalog=HospitalNewDB;Integrated Security=True;Trusted_Connection=True;";
                cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Connection = con;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return cmd;
        }//end of CreateCommand() function

        public static int AddPatientDAL(Patient newPatient)
        {
            int patientAdded = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_AddPatient";
                cmdobj.Parameters.AddWithValue("@patientId", newPatient.PatientId);
                cmdobj.Parameters.AddWithValue("@patientName", newPatient.PatientName);
                cmdobj.Parameters.AddWithValue("@patientGender", newPatient.PatientGender);
                cmdobj.Parameters.AddWithValue("@patientAge", newPatient.PatientAge);
                cmdobj.Parameters.AddWithValue("@patientAddress", newPatient.PatientAddress);
                cmdobj.Parameters.AddWithValue("@contact", newPatient.Contact);
                cmdobj.Parameters.AddWithValue("@patientWeight", newPatient.PatientWeight);
                cmdobj.Parameters.AddWithValue("@Disease", newPatient.Disease);
                cmdobj.Parameters.AddWithValue("@DoctorId", newPatient.DoctorId);
                cmdobj.Connection.Open();
                patientAdded = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAdded;
        }


        public static int AddLabReportDAL(Patient newPatient)
        {
            int reportAdded = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_AddLabReport";
                cmdobj.Parameters.AddWithValue("@Name", newPatient.PatientName);
                cmdobj.Parameters.AddWithValue("@TestDate", newPatient.Testdate);
                cmdobj.Parameters.AddWithValue("@DoctorName", newPatient.DoctorName);
                cmdobj.Parameters.AddWithValue("@TestType", newPatient.Testtype);
                cmdobj.Parameters.AddWithValue("@Remarks", newPatient.Remarks);
                cmdobj.Connection.Open();
                reportAdded = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return reportAdded;
        }

        public static int AddBillReport(Patient newPatient)
        {
            int reportAdded = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "AddBill";
                cmdobj.Parameters.AddWithValue("@Billno", newPatient.BillNo);
                cmdobj.Parameters.AddWithValue("@Patientid", newPatient.PatientId);
                cmdobj.Parameters.AddWithValue("@Patienttype", newPatient.PatientType);
                cmdobj.Parameters.AddWithValue("@Doctorid", newPatient.DoctorId);
                cmdobj.Parameters.AddWithValue("@DoctorFees", newPatient.DoctorFees);
                cmdobj.Parameters.AddWithValue("@Roomcharge", newPatient.Roomcharge);
                cmdobj.Parameters.AddWithValue("@Operationcharges", newPatient.Operationcharges);
                cmdobj.Parameters.AddWithValue("@Totaldays", newPatient.Totaldays);
                cmdobj.Parameters.AddWithValue("@Medicinefees", newPatient.Medicinefees);
                cmdobj.Parameters.AddWithValue("@Labfees", newPatient.Labfees);                
                cmdobj.Connection.Open();
                reportAdded = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return reportAdded;
        }


        public static DataTable DisplayPatientDAL()
        {
            DataTable dtPatient = new DataTable();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetAllPatients";

                cmdobj.Connection.Open();
                SqlDataReader dr = cmdobj.ExecuteReader();
                dtPatient.Load(dr);
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtPatient;
        }

        public static DataSet DisplayPatientByIdDAL(string pid)
        {
            DataSet dsobj = new DataSet();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetPatientById";
                cmdobj.Parameters.AddWithValue("@pid", pid);
                cmdobj.Connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(cmdobj);
                adapter.Fill(dsobj, "Patient");
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsobj;
        }
        public static DataTable DisplayAppointmentDAL()
        {
            DataTable dtAppointment = new DataTable();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetAllAppointments";

                cmdobj.Connection.Open();
                SqlDataReader dr = cmdobj.ExecuteReader();
                dtAppointment.Load(dr);
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtAppointment;
        }

        public static int DeletePatientDAL(string deletepatientID)
        {
            int patientDeleted = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_DeletePatient";
                cmdobj.Parameters.AddWithValue("@pid", deletepatientID);
                cmdobj.Connection.Open();
                patientDeleted = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientDeleted;
        }
        public static List<string> GetPIDs()
        {
            List<string> listOfIds = new List<string>();
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_GetAllPatients";
                cmdobj.Connection.Open();
                SqlDataReader drIds = cmdobj.ExecuteReader();
                listOfIds.Add("Select");
                if (drIds.HasRows)
                {
                    while (drIds.Read())
                    {
                        listOfIds.Add(drIds["PatientId"].ToString());
                    }
                }
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listOfIds;
        }
        

        public static int UpdatePatientDAL(Patient updatePatient)
        {
            int patientUpdated = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_UpdatePatientById";
                cmdobj.Parameters.AddWithValue("@patientId", updatePatient.PatientId);
                cmdobj.Parameters.AddWithValue("@patientName", updatePatient.PatientName);
                cmdobj.Parameters.AddWithValue("@patientGender", updatePatient.PatientGender);
                cmdobj.Parameters.AddWithValue("@patientAge", updatePatient.PatientAge);
                cmdobj.Parameters.AddWithValue("@patientAddress", updatePatient.PatientAddress);
                cmdobj.Parameters.AddWithValue("@contact", updatePatient.Contact);
                cmdobj.Parameters.AddWithValue("@patientWeight", updatePatient.PatientWeight);
                cmdobj.Parameters.AddWithValue("@Disease", updatePatient.Disease);
                cmdobj.Parameters.AddWithValue("@DoctorId", updatePatient.DoctorId);
                cmdobj.Connection.Open();
                patientUpdated = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientUpdated;
        }  //end of updated function     


        public static int BookAppointmentDAL(Patient newPatient)
        {
            int appointmentBooked = 0;
            try
            {
                SqlCommand cmdobj = CreateCommand();
                cmdobj.CommandText = "prc_BookAppointment";
                cmdobj.Parameters.AddWithValue("@patientId", newPatient.PatientId);
                cmdobj.Parameters.AddWithValue("@patientName", newPatient.PatientName);
                cmdobj.Parameters.AddWithValue("@AppointmentId", newPatient.AppointmentId);
                cmdobj.Parameters.AddWithValue("@patientGender", newPatient.PatientGender);
                cmdobj.Parameters.AddWithValue("@patientAge", newPatient.PatientAge);
                cmdobj.Parameters.AddWithValue("@patientAddress", newPatient.PatientAddress);
                cmdobj.Parameters.AddWithValue("@contact", newPatient.Contact);
                cmdobj.Parameters.AddWithValue("@patientWeight", newPatient.PatientWeight);
                cmdobj.Parameters.AddWithValue("@Disease", newPatient.Disease);
                cmdobj.Parameters.AddWithValue("@DoctorName", newPatient.DoctorName);
                cmdobj.Parameters.AddWithValue("@date", newPatient.Date);
                cmdobj.Parameters.AddWithValue("@Remarks", newPatient.Remarks);
                cmdobj.Connection.Open();
                appointmentBooked = cmdobj.ExecuteNonQuery();
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return appointmentBooked;
        }

    } //end of class
} //end of namespace
