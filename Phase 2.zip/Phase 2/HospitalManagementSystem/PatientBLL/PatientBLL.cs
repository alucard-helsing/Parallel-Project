﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using PatientEntity;
using PatientDAL;
using System.IO;
using System.Data;
using System.Data.SqlClient;
using HospitalManagementSystem;

namespace PatientBLL
{
    public class PatientBLL
    {
        private static bool ValidatePatient(Patient patient)
        {
            StringBuilder sb = new StringBuilder();
            bool validPatient = true;
            try
            {
                if (patient.PatientId == string.Empty)
                {
                    validPatient = false;
                    sb.Append(Environment.NewLine + "Patient Id is Required can't be blank");

                }
                
                if (validPatient == false)
                    throw new HospitalManagementSystem.HMSException(sb.ToString());
            }
            catch (HospitalManagementSystem.HMSException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return validPatient;
        }//end of ValidatePatient()

        public static int AddPatientBL(Patient newPatient)
        {
            int patientAdded = 0;
            try
            {
                if (ValidatePatient(newPatient))
                {
                    patientAdded = PatientDAL.PatientDAL.AddPatientDAL(newPatient);
                }
                else
                    throw new HospitalManagementSystem.HMSException("Patient data is invalid");
            }
            catch (HospitalManagementSystem.HMSException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientAdded;
        }//end of AddPatientBL()

        public static int AddLabReportBL(Patient newPatient)
        {
            int reportAdded = 0;
            try
            {

                if (ValidatePatient(newPatient))
                {
                    reportAdded = PatientDAL.PatientDAL.AddLabReportDAL(newPatient);
                }
                else
                    throw new HMSException("Report data is invalid");
            }
            catch (HMSException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return reportAdded;
        }


        public static int AddBill(Patient newPatient)
        {
            int billadded = 0;
            try
            {
                if (ValidatePatient(newPatient))
                {
                    billadded = PatientDAL.PatientDAL.AddBillReport(newPatient);
                }
                else
                    throw new HospitalManagementSystem.HMSException("Patient data is invalid");
            }
            catch (HospitalManagementSystem.HMSException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return billadded;
        }

        public static DataTable DisplayPatient()
        {
            DataTable dtPatient = null;
            try
            {
                dtPatient = PatientDAL.PatientDAL.DisplayPatientDAL();
            }
            catch (HospitalManagementSystem.HMSException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtPatient;
        }//end of DisplayPatient()

        public static DataTable DisplayAppointment()
        {
            DataTable dtPatient = null;
            try
            {
                dtPatient = PatientDAL.PatientDAL.DisplayAppointmentDAL();
            }
            catch (HospitalManagementSystem.HMSException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dtPatient;
        }//end of DisplayPatient()

        public static DataSet DisplayPatientByIdBL(string pid)
        {
            DataSet dsobj = new DataSet();
            try
            {
                dsobj = PatientDAL.PatientDAL.DisplayPatientByIdDAL(pid);
            }
            catch (HospitalManagementSystem.HMSException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsobj;
        }

        public static int DeletePatientBL(string deletePatientID)
        {
            int patientDeleted = 0;
            try
            {
                patientDeleted = PatientDAL.PatientDAL.DeletePatientDAL(deletePatientID);
            }
            catch (HospitalManagementSystem.HMSException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientDeleted;
        } //end of DeletePatientBL()
        public static List<string> GetPIDs()
        {
            List<string> listObj = null;
            try
            {
                listObj = PatientDAL.PatientDAL.GetPIDs();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return listObj;
        }




        public static int UpdatePatientBL(Patient updatePatient)
        {
            int patientUpdated = 0;
            try
            {
                if (ValidatePatient(updatePatient))
                {
                    patientUpdated = PatientDAL.PatientDAL.UpdatePatientDAL(updatePatient);
                }
                else
                    throw new HospitalManagementSystem.HMSException("Invalid Patient data for updation");
            }
            catch (HospitalManagementSystem.HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientUpdated;
        }//end of UpdatePatientBL()

        public static int BookAppointmentBL(Patient newPatient)
        {
            int appointmentBooked = 0;
            try
            {
                if (ValidatePatient(newPatient))
                {
                    appointmentBooked = PatientDAL.PatientDAL.BookAppointmentDAL(newPatient);
                }
                else
                    throw new HospitalManagementSystem.HMSException("Patient data is invalid");
            }
            catch (HospitalManagementSystem.HMSException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return appointmentBooked;
        }//end of AddPatientBL()
    }
}
