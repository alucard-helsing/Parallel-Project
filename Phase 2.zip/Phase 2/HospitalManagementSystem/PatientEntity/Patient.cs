﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientEntity
{
    public class Patient
    {
        public string PatientId { get; set; }
        public string PatientName { get; set; }
        public string PatientGender { get; set; }
        public int PatientAge { get; set; }
        public string PatientAddress { get; set; }
        public string Contact { get; set; }
        public int PatientWeight { get; set; }
        public string Disease { get; set; }
        public int DoctorId { get; set; }

        public string DoctorName { get; set; }
        public string Remarks { get; set; }
        public string AppointmentId { get; set; }
        public DateTime Date { get; set; }

        public string ReportId { get; set; }
        public DateTime Testdate { get; set; }
        public string Testtype { get; set; }

        public string PatientType { get; set; }
        public int BillNo { get; set; }
        public int DoctorFees { get; set; }
        public int Roomcharge { get; set; }
        public int Operationcharges { get; set; }
        public int Medicinefees { get; set; }
        public int Totaldays { get; set; }
        public int Labfees { get; set; }
        public int Amount { get; set; }
        


    }
}
