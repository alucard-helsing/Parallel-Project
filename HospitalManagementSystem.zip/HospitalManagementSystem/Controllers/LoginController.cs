﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HospitalManagementSystem.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login

        SqlConnection connection = new SqlConnection(@"Data Source=DESKTOP-92E98T7;Initial Catalog=HospitalNewDB;Integrated Security=True");
        SqlCommand command;
        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(FormCollection formCollection)
        {

            command = new SqlCommand();
            command.CommandType = CommandType.StoredProcedure;
            command.CommandText = "usp_SearchRegister";
            command.Parameters.AddWithValue("@username", formCollection["UserName"]);
            command.Parameters.AddWithValue("@pass", formCollection["Password"]);
            command.Connection = connection;

            connection.Open();
            SqlDataReader reader = command.ExecuteReader();
            if (reader.HasRows)
            {
                Session["GotAccess"] = formCollection["UserName"];
                return RedirectToAction("Index", "Home");
            }

            connection.Close();

            return View();
        }

    }
}