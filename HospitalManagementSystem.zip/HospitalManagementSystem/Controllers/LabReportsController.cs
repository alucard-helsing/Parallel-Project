﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Controllers
{
    public class LabReportsController : Controller
    {
        private HospitalNewDBEntities db = new HospitalNewDBEntities();

        // GET: LabReports
        public ActionResult Index()
        {
            return View(db.LabReports.ToList());
        }

        // GET: LabReports/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            LabReport labReport = db.LabReports.Find(id);
            if (labReport == null)
            {
                return HttpNotFound();
            }
            return View(labReport);
        }

        // GET: LabReports/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: LabReports/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ReportId,Name,Testdate,DoctorName,TestType,Remarks")] LabReport labReport)
        {
            if (ModelState.IsValid)
            {
                db.LabReports.Add(labReport);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(labReport);
        }

        // GET: LabReports/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            LabReport labReport = db.LabReports.Find(id);
            if (labReport == null)
            {
                return HttpNotFound();
            }
            return View(labReport);
        }

        // POST: LabReports/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ReportId,Name,Testdate,DoctorName,TestType,Remarks")] LabReport labReport)
        {
            if (ModelState.IsValid)
            {
                db.Entry(labReport).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(labReport);
        }

        // GET: LabReports/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            LabReport labReport = db.LabReports.Find(id);
            if (labReport == null)
            {
                return HttpNotFound();
            }
            return View(labReport);
        }

        // POST: LabReports/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            LabReport labReport = db.LabReports.Find(id);
            db.LabReports.Remove(labReport);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
