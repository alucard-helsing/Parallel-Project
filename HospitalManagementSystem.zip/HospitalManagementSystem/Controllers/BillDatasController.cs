﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Controllers
{
    public class BillDatasController : Controller
    {
        private HospitalNewDBEntities db = new HospitalNewDBEntities();

        // GET: BillDatas
        public ActionResult Index()
        {
            var billDatas = db.BillDatas.Include(b => b.Doctor).Include(b => b.Doctor1).Include(b => b.Patient);
            return View(billDatas.ToList());
        }

        // GET: BillDatas/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BillData billData = db.BillDatas.Find(id);
            if (billData == null)
            {
                return HttpNotFound();
            }
            return View(billData);
        }

        // GET: BillDatas/Create
        public ActionResult Create()
        {
            ViewBag.DoctorId = new SelectList(db.Doctors, "DoctorId", "DoctorName");
            ViewBag.DoctorId = new SelectList(db.Doctors, "DoctorId", "DoctorName");
            ViewBag.PatientId = new SelectList(db.Patients, "patientid", "patientname");
            return View();
        }

        // POST: BillDatas/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "BillNo,PatientId,PatientType,DoctorId,DoctorFees,RoomCharge,OperationCharges,MedicineFees,TotalDays,LabFees,Amount")] BillData billData)
        {
            if (ModelState.IsValid)
            {
                db.BillDatas.Add(billData);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DoctorId = new SelectList(db.Doctors, "DoctorId", "DoctorName", billData.DoctorId);
            ViewBag.DoctorId = new SelectList(db.Doctors, "DoctorId", "DoctorName", billData.DoctorId);
            ViewBag.PatientId = new SelectList(db.Patients, "patientid", "patientname", billData.PatientId);
            return View(billData);
        }

        // GET: BillDatas/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BillData billData = db.BillDatas.Find(id);
            if (billData == null)
            {
                return HttpNotFound();
            }
            ViewBag.DoctorId = new SelectList(db.Doctors, "DoctorId", "DoctorName", billData.DoctorId);
            ViewBag.DoctorId = new SelectList(db.Doctors, "DoctorId", "DoctorName", billData.DoctorId);
            ViewBag.PatientId = new SelectList(db.Patients, "patientid", "patientname", billData.PatientId);
            return View(billData);
        }

        // POST: BillDatas/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "BillNo,PatientId,PatientType,DoctorId,DoctorFees,RoomCharge,OperationCharges,MedicineFees,TotalDays,LabFees,Amount")] BillData billData)
        {
            if (ModelState.IsValid)
            {
                db.Entry(billData).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DoctorId = new SelectList(db.Doctors, "DoctorId", "DoctorName", billData.DoctorId);
            ViewBag.DoctorId = new SelectList(db.Doctors, "DoctorId", "DoctorName", billData.DoctorId);
            ViewBag.PatientId = new SelectList(db.Patients, "patientid", "patientname", billData.PatientId);
            return View(billData);
        }

        // GET: BillDatas/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BillData billData = db.BillDatas.Find(id);
            if (billData == null)
            {
                return HttpNotFound();
            }
            return View(billData);
        }

        // POST: BillDatas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            BillData billData = db.BillDatas.Find(id);
            db.BillDatas.Remove(billData);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
