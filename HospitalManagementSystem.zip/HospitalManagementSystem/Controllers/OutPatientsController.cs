﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Controllers
{
    public class OutPatientsController : Controller
    {
        private HospitalNewDBEntities db = new HospitalNewDBEntities();

        // GET: OutPatients
        public ActionResult Index()
        {
            var outPatients = db.OutPatients.Include(o => o.Doctor).Include(o => o.Lab);
            return View(outPatients.ToList());
        }

        // GET: OutPatients/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OutPatient outPatient = db.OutPatients.Find(id);
            if (outPatient == null)
            {
                return HttpNotFound();
            }
            return View(outPatient);
        }

        // GET: OutPatients/Create
        public ActionResult Create()
        {
            ViewBag.DoctorIdId = new SelectList(db.Doctors, "DoctorId", "DoctorName");
            ViewBag.LabId = new SelectList(db.Labs, "labId", "patientId");
            return View();
        }

        // POST: OutPatients/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "PatientId,TreatmentData,DoctorIdId,LabId")] OutPatient outPatient)
        {
            if (ModelState.IsValid)
            {
                db.OutPatients.Add(outPatient);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DoctorIdId = new SelectList(db.Doctors, "DoctorId", "DoctorName", outPatient.DoctorIdId);
            ViewBag.LabId = new SelectList(db.Labs, "labId", "patientId", outPatient.LabId);
            return View(outPatient);
        }

        // GET: OutPatients/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OutPatient outPatient = db.OutPatients.Find(id);
            if (outPatient == null)
            {
                return HttpNotFound();
            }
            ViewBag.DoctorIdId = new SelectList(db.Doctors, "DoctorId", "DoctorName", outPatient.DoctorIdId);
            ViewBag.LabId = new SelectList(db.Labs, "labId", "patientId", outPatient.LabId);
            return View(outPatient);
        }

        // POST: OutPatients/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "PatientId,TreatmentData,DoctorIdId,LabId")] OutPatient outPatient)
        {
            if (ModelState.IsValid)
            {
                db.Entry(outPatient).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DoctorIdId = new SelectList(db.Doctors, "DoctorId", "DoctorName", outPatient.DoctorIdId);
            ViewBag.LabId = new SelectList(db.Labs, "labId", "patientId", outPatient.LabId);
            return View(outPatient);
        }

        // GET: OutPatients/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            OutPatient outPatient = db.OutPatients.Find(id);
            if (outPatient == null)
            {
                return HttpNotFound();
            }
            return View(outPatient);
        }

        // POST: OutPatients/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            OutPatient outPatient = db.OutPatients.Find(id);
            db.OutPatients.Remove(outPatient);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
