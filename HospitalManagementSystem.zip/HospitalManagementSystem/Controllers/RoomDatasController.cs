﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Controllers
{
    public class RoomDatasController : Controller
    {
        private HospitalNewDBEntities db = new HospitalNewDBEntities();

        // GET: RoomDatas
        public ActionResult Index()
        {
            var roomDatas = db.RoomDatas.Include(r => r.Doctor).Include(r => r.Lab);
            return View(roomDatas.ToList());
        }

        // GET: RoomDatas/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RoomData roomData = db.RoomDatas.Find(id);
            if (roomData == null)
            {
                return HttpNotFound();
            }
            return View(roomData);
        }

        // GET: RoomDatas/Create
        public ActionResult Create()
        {
            ViewBag.DocId = new SelectList(db.Doctors, "DoctorId", "DoctorName");
            ViewBag.LabId = new SelectList(db.Labs, "labId", "patientId");
            return View();
        }

        // POST: RoomDatas/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "RoomNumber,TreatmentData,DocId,LabId")] RoomData roomData)
        {
            if (ModelState.IsValid)
            {
                db.RoomDatas.Add(roomData);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DocId = new SelectList(db.Doctors, "DoctorId", "DoctorName", roomData.DocId);
            ViewBag.LabId = new SelectList(db.Labs, "labId", "patientId", roomData.LabId);
            return View(roomData);
        }

        // GET: RoomDatas/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RoomData roomData = db.RoomDatas.Find(id);
            if (roomData == null)
            {
                return HttpNotFound();
            }
            ViewBag.DocId = new SelectList(db.Doctors, "DoctorId", "DoctorName", roomData.DocId);
            ViewBag.LabId = new SelectList(db.Labs, "labId", "patientId", roomData.LabId);
            return View(roomData);
        }

        // POST: RoomDatas/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "RoomNumber,TreatmentData,DocId,LabId")] RoomData roomData)
        {
            if (ModelState.IsValid)
            {
                db.Entry(roomData).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DocId = new SelectList(db.Doctors, "DoctorId", "DoctorName", roomData.DocId);
            ViewBag.LabId = new SelectList(db.Labs, "labId", "patientId", roomData.LabId);
            return View(roomData);
        }

        // GET: RoomDatas/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            RoomData roomData = db.RoomDatas.Find(id);
            if (roomData == null)
            {
                return HttpNotFound();
            }
            return View(roomData);
        }

        // POST: RoomDatas/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            RoomData roomData = db.RoomDatas.Find(id);
            db.RoomDatas.Remove(roomData);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
