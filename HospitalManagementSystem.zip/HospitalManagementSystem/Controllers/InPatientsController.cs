﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HospitalManagementSystem.Models;

namespace HospitalManagementSystem.Controllers
{
    public class InPatientsController : Controller
    {
        private HospitalNewDBEntities db = new HospitalNewDBEntities();

        // GET: InPatients
        public ActionResult Index()
        {
            var inPatients = db.InPatients.Include(i => i.Doctor).Include(i => i.Lab);
            return View(inPatients.ToList());
        }

        // GET: InPatients/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            InPatient inPatient = db.InPatients.Find(id);
            if (inPatient == null)
            {
                return HttpNotFound();
            }
            return View(inPatient);
        }

        // GET: InPatients/Create
        public ActionResult Create()
        {
            ViewBag.DoctorId = new SelectList(db.Doctors, "DoctorId", "DoctorName");
            ViewBag.LabId = new SelectList(db.Labs, "labId", "patientId");
            return View();
        }

        // POST: InPatients/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "PatientId,RoomNumber,DoctorId,AdmDate,DisDate,LabId,Amount")] InPatient inPatient)
        {
            if (ModelState.IsValid)
            {
                db.InPatients.Add(inPatient);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.DoctorId = new SelectList(db.Doctors, "DoctorId", "DoctorName", inPatient.DoctorId);
            ViewBag.LabId = new SelectList(db.Labs, "labId", "patientId", inPatient.LabId);
            return View(inPatient);
        }

        // GET: InPatients/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            InPatient inPatient = db.InPatients.Find(id);
            if (inPatient == null)
            {
                return HttpNotFound();
            }
            ViewBag.DoctorId = new SelectList(db.Doctors, "DoctorId", "DoctorName", inPatient.DoctorId);
            ViewBag.LabId = new SelectList(db.Labs, "labId", "patientId", inPatient.LabId);
            return View(inPatient);
        }

        // POST: InPatients/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "PatientId,RoomNumber,DoctorId,AdmDate,DisDate,LabId,Amount")] InPatient inPatient)
        {
            if (ModelState.IsValid)
            {
                db.Entry(inPatient).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.DoctorId = new SelectList(db.Doctors, "DoctorId", "DoctorName", inPatient.DoctorId);
            ViewBag.LabId = new SelectList(db.Labs, "labId", "patientId", inPatient.LabId);
            return View(inPatient);
        }

        // GET: InPatients/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            InPatient inPatient = db.InPatients.Find(id);
            if (inPatient == null)
            {
                return HttpNotFound();
            }
            return View(inPatient);
        }

        // POST: InPatients/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            InPatient inPatient = db.InPatients.Find(id);
            db.InPatients.Remove(inPatient);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
