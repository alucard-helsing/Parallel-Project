﻿using HMSEnity;
using HMSException;
using PatientDAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace HMSBLL
{
    public class HMSBLL
    {
        private static bool ValidatePatient(Patient patient)
        {
            StringBuilder sb = new StringBuilder();
            bool validPatient = true;
            if (patient.PatientId == null)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient Id is Required cannnot be blank");
            }
            if (patient.PatientName == string.Empty)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient Name Required");
            }
            //if (patient.PhoneNo.Length < 10)
            //{
            //    validPatient = false;
            //    sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            //}
            //else if (!Regex.IsMatch(patient.PhoneNo, "[7-9][0-9]{9}"))
            //{
            //    sb.Append("Phone number should start with 7 or 8 or 9 and it should have exactly 10 digits\n");
            //    validPatient = false;
            //}
            //if (patient.AppointmentId == string.Empty)
            //{
            //    validPatient = false;
            //    sb.Append(Environment.NewLine + "Appointment Id is Required cannnot be blank");
            //}
            //if (patient.DoctorName == string.Empty)
            //{
            //    validPatient = false;
            //    sb.Append(Environment.NewLine + "Doctor Name Required");
            //}
            //if (validPatient == false)
            //    throw new HMSException.HMSException(sb.ToString());
            return validPatient;

        }

        private static bool ValidateLabRecord(Lab lab)
        {
            StringBuilder sb = new StringBuilder();
            bool validLabRecord = true;

            return validLabRecord;
        }

        private static bool ValidateBill(Bill bill)
        {
            StringBuilder sb = new StringBuilder();
            bool ValidBill = true;
            return ValidBill;
        }

        public static int AddPatientBL(Patient patient)

        {
            int patientAdded = 0;
            try
            {
                if (ValidatePatient(patient))
                {
                    patientAdded = PatientDAL.PatientDAL.AddPatientDAL(patient);
                }
            }
            catch (HMSException.HMSException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }

            return patientAdded;
        }

        public static DataSet SearchPatientBLL(string Pid,DateTime Dov,string DName,DateTime Doa,DateTime Dod)
        {
            DataSet searchPatient = null;
            try
            {
                searchPatient = PatientDAL.PatientDAL.SearchPatientDAL(Pid, Dov, DName, Doa, Dod);
            }
            catch (HMSException.HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;
        }

        public static Patient GetPatientByIdBLL(string searchPatientID)
        {
            Patient searchPatient = null;
            try
            {
                searchPatient = PatientDAL.PatientDAL.GetPatientByIdDAL(searchPatientID);
            }
            catch (HMSException.HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;
        }

        public static int DeletePatientBL(string deletePatientId)
        {
            int patientDeleted = 0;
            try
            {
                if(deletePatientId!=null)
                {
                    patientDeleted = PatientDAL.PatientDAL.DeletePatientDAL(deletePatientId);
                }
                else
                {
                    throw new HMSException.HMSException("Invalid Patient Id");
                }
            }
            catch(HMSException.HMSException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientDeleted;
        }

        public static List<Patient> GetAllPatientsBL()
        {
            List<Patient> PatientList = null;
            try
            {
                PatientList = PatientDAL.PatientDAL.GetAllPatientsDAL();
            }
            catch(HMSException.HMSException ex)
            {
                throw ex;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return PatientList;
        }

        public static int UpdatePatientBL(Patient updatePatient)
        {
            int patientUpdated = 0;
            try
            {
                if (ValidatePatient(updatePatient))
                {
                    PatientDAL.PatientDAL patientDAL = new PatientDAL.PatientDAL();
                    patientUpdated = PatientDAL.PatientDAL.UpdatePatientDAL(updatePatient);
                }
            }
            catch (HMSException.HMSException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientUpdated;
        }

        public static int AddLabBL(Lab lab)
        {

            int labAdded = 0;
            try
            {
                if (ValidateLabRecord(lab))
                {
                    labAdded = PatientDAL.PatientDAL.AddLabDAL(lab);
                }
            }
            catch (HMSException.HMSException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }

            return labAdded;
        }

        public static List<Lab> GetAllLabRecordsBL()
        {
            List<Lab> LabList = null;
            try
            {
                LabList = PatientDAL.PatientDAL.GetAllLabRecordsDAL();
            }
            catch (HMSException.HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return LabList;
        }

        public static int DeleteLabRecordBL(string lid)
        {

            int labRecordDeleted = 0;
            try
            {
                if (lid != null)
                {
                    labRecordDeleted = PatientDAL.PatientDAL.DeleteLabRecordDAL(lid);
                }
                else
                {
                    throw new HMSException.HMSException("Invalid Lab Id");
                }
            }
            catch (HMSException.HMSException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return labRecordDeleted;
        }

        public static int UpdateLabRecordBL(Lab updatelab)
        {
            int labRecordUpdated = 0;
            try
            {
                if (ValidateLabRecord(updatelab))
                {
                    PatientDAL.PatientDAL patientDAL = new PatientDAL.PatientDAL();
                    labRecordUpdated = PatientDAL.PatientDAL.UpdateLabRecord(updatelab);
                }
            }
            catch (HMSException.HMSException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return labRecordUpdated;
        }

        public static int AddBillBL(Bill bill)
        {
            int billaddded = 0;
            try
            {
                if (ValidateBill(bill))
                {
                    billaddded = PatientDAL.PatientDAL.AddBillDAL(bill);
                }
            }
            catch (HMSException.HMSException e)
            {
                throw e;
            }
            catch (Exception ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }

            return billaddded;
        }

        public static List<Bill> GetAllBillsBL()
        {
            List<Bill> billsList = null;
            try
            {
                billsList = PatientDAL.PatientDAL.GetAllBillsDAL();
            }
            catch (HMSException.HMSException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billsList;
        }

        public static int DeleteBillBL(string bid)
        {
            int billDeleted = 0;
            try
            {
                if (bid != null)
                {
                    billDeleted = PatientDAL.PatientDAL.DeleteBillDAL(bid);
                }
                else
                {
                    throw new HMSException.HMSException("Invalid Bill Id");
                }
            }
            catch (HMSException.HMSException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billDeleted;
        }

        public static int UpdateBillBL(Bill updatebill)
        {
            int labBillUpdated = 0;
            try
            {
                if (ValidateBill(updatebill))
                {
                    PatientDAL.PatientDAL patientDAL = new PatientDAL.PatientDAL();
                    labBillUpdated = PatientDAL.PatientDAL.UpdateBillDAL(updatebill);
                }
            }
            catch (HMSException.HMSException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return labBillUpdated;
        }
    }
}
