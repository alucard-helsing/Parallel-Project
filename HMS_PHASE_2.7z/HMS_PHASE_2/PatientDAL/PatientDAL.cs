﻿using HMSEnity;
using HMSException;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PatientDAL
{
    public class PatientDAL
    {
        

        public static SqlCommand CreateCommand()
        {
            SqlCommand cmd = null;
            try
            {
                SqlConnection conobj = new SqlConnection();
                conobj.ConnectionString = "Data Source=DESKTOP-92E98T7;Initial Catalog=HMS;Integrated Security=True";
                cmd = new SqlCommand();
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Connection = conobj;
            }
            catch(SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return cmd;
        }

        public static int AddPatientDAL(Patient patient)
        {
            int patientAdded = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_Insertpatients";

                cmd.Parameters.AddWithValue("@PatientId", patient.PatientId);
                cmd.Parameters.AddWithValue("@Name", patient.PatientName);
                cmd.Parameters.AddWithValue("@Age", patient.Age);
                cmd.Parameters.AddWithValue("@Weight", patient.Weight);
                cmd.Parameters.AddWithValue("@Gender", patient.Gender);
                cmd.Parameters.AddWithValue("@Address", patient.Address);
                cmd.Parameters.AddWithValue("@PhoneNo", patient.PhoneNo);
                cmd.Parameters.AddWithValue("@Disease", patient.Disease);
                cmd.Parameters.AddWithValue("@DoctorId", patient.DoctorId);
                cmd.Connection.Open();
                patientAdded = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientAdded;
        }

        public static DataSet SearchPatientDAL(string sPid, DateTime sDov, string sDName, DateTime sDoa, DateTime sDod)
        {
            DataSet searchPatient = new DataSet();
            try
            {
                SqlCommand cmdobj = new SqlCommand();
                cmdobj.CommandText = "prc_SearchPatient";
                cmdobj.Parameters.AddWithValue("@PatientId", sPid);
                cmdobj.Parameters.AddWithValue("@DateOfVisit", sDov);
                cmdobj.Parameters.AddWithValue("@DoctorName", sDName);
                cmdobj.Parameters.AddWithValue("@AdmissionDate", sDoa);
                cmdobj.Parameters.AddWithValue("@DischargeDate", sDod);
                cmdobj.Connection.Open();
                SqlDataAdapter adapter = new SqlDataAdapter(cmdobj);
                adapter.Fill(searchPatient, "Patient");
                cmdobj.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;
        }

        public static Patient GetPatientByIdDAL(string searchPatientID)
        {
            Patient searchpatient = null;
            Patient patient = new Patient();
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_GetPatientById";
                cmd.Parameters.AddWithValue("@PatientId", searchPatientID);
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    searchpatient = new Patient();
                    searchpatient.PatientId = patient.PatientId;
                    searchpatient.PatientName = patient.PatientName;
                    searchpatient.Age = patient.Age;
                    searchpatient.Weight = patient.Weight;
                    searchpatient.Gender = patient.Gender;
                    searchpatient.Address = patient.Address;
                    searchpatient.PhoneNo = patient.PhoneNo;
                    searchpatient.Disease = patient.Disease;
                    searchpatient.DoctorId = patient.DoctorId;
                }
            }
            catch(Exception ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
            return searchpatient;
        }

        public static int DeletePatientDAL(string PatientId)
        {
            int patientDeleted = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_DeletePatient";
                cmd.Parameters.AddWithValue("@PatientId", PatientId);
                cmd.Connection.Open();
                patientDeleted = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientDeleted;
        }

        public static List<Patient> GetAllPatientsDAL()
        {
            List<Patient> PatientList = null;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_Getpatients";
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                PatientList = new List<Patient>();
                while(dr.Read())
                {
                    Patient patient = new Patient();
                    patient.PatientId = dr.GetString(0);
                    patient.PatientName = dr.GetString(1);
                    patient.Age = dr.GetInt32(2);
                    patient.Weight = dr.GetInt32(3);
                    patient.Gender= Convert.ToChar(dr.GetString(4));
                    patient.Address = dr.GetString(5);
                    patient.PhoneNo =dr.GetInt64(6);
                    patient.Disease = dr.GetString(7);
                    patient.DoctorId = dr.GetString(8);
                    PatientList.Add(patient);
                }
            }
            catch (Exception ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
            return PatientList;
        }

        public static List<Lab> GetAllLabRecordsDAL()
        {
            List<Lab> LabList = null;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_GetLabRecords";
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                LabList = new List<Lab>();
                while (dr.Read())
                {
                    Lab lab = new Lab();
                    lab.LabId = dr.GetString(0);
                    lab.PatientId = dr.GetString(1);
                    lab.DoctorID = dr.GetString(2);
                    //lab.TestDate = Convert.ToDateTime(dr.GetString(3));
                    lab.TestType = dr.GetString(4);
                    lab.PatientType = dr.GetString(5);
                    LabList.Add(lab);
                }
            }
            catch (Exception ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
            return LabList;
        }

        public static int UpdateLabRecord(Lab updatelab)
        {
            int labUpdated = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_UpdatelabRecord";

                cmd.Parameters.AddWithValue("@LabId", updatelab.LabId);
                cmd.Parameters.AddWithValue("@PId", updatelab.PatientId);
                cmd.Parameters.AddWithValue("@DoctorId", updatelab.DoctorID);
                cmd.Parameters.AddWithValue("@TestDate", updatelab.TestDate);
                cmd.Parameters.AddWithValue("@TestType", updatelab.TestType);
                cmd.Parameters.AddWithValue("@PatientType", updatelab.PatientType);
                cmd.Connection.Open();
                labUpdated = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return labUpdated;
        }

        public static int AddBillDAL(Bill bill)
        {
            int billadded = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_InsertBill";
                cmd.Parameters.AddWithValue("@BillNo", bill.BillNo);
                cmd.Parameters.AddWithValue("@PId", bill.PId);
                cmd.Parameters.AddWithValue("@PatientType", bill.PatientType);
                cmd.Parameters.AddWithValue("@DoctorId", bill.DoctorId);
                cmd.Parameters.AddWithValue("@DoctorFees", bill.DoctorFees);
                cmd.Parameters.AddWithValue("@RoomCharge", bill.RoomCharge);
                cmd.Parameters.AddWithValue("@OperationCharges", bill.OperationCharge);
                cmd.Parameters.AddWithValue("@MedicineFees", bill.MedicineFees);
                cmd.Parameters.AddWithValue("@TotalDays", bill.TotalDays);
                cmd.Parameters.AddWithValue("@LabFees", bill.LabFees);
                cmd.Parameters.AddWithValue("@TotalAmount", bill.TotalAmount);
                cmd.Connection.Open();
                billadded = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billadded;
        }

        public static int UpdateBillDAL(Bill updatebill)
        {
            int billUpdated = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_UpdateBill";

                cmd.Parameters.AddWithValue("@BillNo", updatebill.BillNo);
                cmd.Parameters.AddWithValue("@PId", updatebill.PId);
                cmd.Parameters.AddWithValue("@PatientType", updatebill.PatientType);
                cmd.Parameters.AddWithValue("@DoctorId", updatebill.DoctorId);
                cmd.Parameters.AddWithValue("@DoctorFees", updatebill.DoctorFees);
                cmd.Parameters.AddWithValue("@RoomCharge", updatebill.RoomCharge);
                cmd.Parameters.AddWithValue("@OperationCharges", updatebill.OperationCharge);
                cmd.Parameters.AddWithValue("@MedicineFees", updatebill.MedicineFees);
                cmd.Parameters.AddWithValue("@TotalDays", updatebill.TotalDays);
                cmd.Parameters.AddWithValue("@LabFees", updatebill.LabFees);
                cmd.Parameters.AddWithValue("@TotalAmount", updatebill.TotalAmount);
                cmd.Connection.Open();
                billUpdated = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billUpdated;
        }

        public static int DeleteBillDAL(string bid)
        {
            int billDeleted = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_DeleteBill";
                cmd.Parameters.AddWithValue("@BillNo", bid);
                cmd.Connection.Open();
                billDeleted = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return billDeleted;
        }

        public static List<Bill> GetAllBillsDAL()
        {
            List<Bill> billList = null;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_GetBills";
                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                billList = new List<Bill>();
                while (dr.Read())
                {
                    Bill bill = new Bill();
                    bill.BillNo = dr.GetString(0);
                    bill.PId = dr.GetString(1);
                    bill.PatientType = dr.GetString(2);
                    bill.DoctorId = dr.GetString(3);
                    bill.DoctorFees = dr.GetDecimal(4);
                    bill.RoomCharge = dr.GetDecimal(5);
                    bill.OperationCharge = dr.GetDecimal(6);
                    bill.MedicineFees = dr.GetDecimal(7);
                    bill.TotalDays = dr.GetDecimal(8);
                    bill.TotalAmount = dr.GetDecimal(9);
                    billList.Add(bill);
                }
            }
            catch (Exception ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
            return billList;
        }

        public static int DeleteLabRecordDAL(string lid)
        {
            int labRecordDeleted = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_DeleteLabRecord";
                cmd.Parameters.AddWithValue("@LabId", lid);
                cmd.Connection.Open();
                labRecordDeleted = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return labRecordDeleted;
        }

        public static int AddLabDAL(Lab lab)
        {
            int labadded = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_InsertLabRecord";

                cmd.Parameters.AddWithValue("@LabId", lab.LabId);
                cmd.Parameters.AddWithValue("@PId", lab.PatientId);
                cmd.Parameters.AddWithValue("@DoctorId", lab.DoctorID);
                cmd.Parameters.AddWithValue("@TestDate", lab.TestDate);
                cmd.Parameters.AddWithValue("@TestType", lab.TestType);
                cmd.Parameters.AddWithValue("@PatientType", lab.PatientType);
                cmd.Connection.Open();
                labadded = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return labadded;
        }

        public static int UpdatePatientDAL(Patient patient)
        {
            int patientUpdated = 0;
            try
            {
                SqlCommand cmd = CreateCommand();
                cmd.CommandText = "prc_Updatepatient";

                cmd.Parameters.AddWithValue("@PatientId", patient.PatientId);
                cmd.Parameters.AddWithValue("@Name", patient.PatientName);
                cmd.Parameters.AddWithValue("@Age", patient.Age);
                cmd.Parameters.AddWithValue("@Weight", patient.Weight);
                cmd.Parameters.AddWithValue("@Gender", patient.Gender);
                cmd.Parameters.AddWithValue("@Address", patient.Address);
                cmd.Parameters.AddWithValue("@PhoneNo", patient.PhoneNo);
                cmd.Parameters.AddWithValue("@Disease", patient.Disease);
                cmd.Parameters.AddWithValue("@DoctorId", patient.DoctorId);
                cmd.Connection.Open();
                patientUpdated = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientUpdated;
        }
    }
}
