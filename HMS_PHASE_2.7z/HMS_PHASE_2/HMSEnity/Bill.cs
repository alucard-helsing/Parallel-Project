﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEnity
{
    public class Bill
    {
        public string BillNo { get; set; }

        public string PId { get; set; }

        public string PatientType { get; set; }

        public string DoctorId { get; set; }

        public decimal DoctorFees { get; set; }

        public decimal RoomCharge { get; set; }

        public decimal OperationCharge { get; set; }

        public decimal MedicineFees { get; set; }

        public decimal TotalDays { get; set; }

        public decimal LabFees { get; set; }

        public decimal TotalAmount { get; set; }
    }
}
