﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEnity
{
    public class Lab
    {
        public string LabId { get; set; }

        public string PatientId { get; set; }

        public string DoctorID { get; set; }

        public DateTime TestDate { get; set; }

        public string TestType { get; set; }

        public string PatientType { get; set; }

    }
}
