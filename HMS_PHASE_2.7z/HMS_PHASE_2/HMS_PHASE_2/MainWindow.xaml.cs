﻿using HMSBLL;
using HMSEnity;
using HMSException;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace HMS_PHASE_2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            //RefreshPatient();
        }

        private void RefreshPatient()
        {
            List<Patient> patientList = HMSBLL.HMSBLL.GetAllPatientsBL();
            if (patientList.Count > 0)
            {
                patientGrid.ItemsSource = patientList.ToList();
            }
            else
                MessageBox.Show("Patient data not available");
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            Patient patient = new Patient();
            try
            {
                patient.PatientId = txtPid.Text;
                patient.PatientName = txtPname.Text;
                patient.Age = int.Parse(txtAge.Text);
                patient.Weight = int.Parse(txtWeight.Text);
                if (rdMale.IsChecked == true || rdFemale.IsChecked == false)
                {
                    patient.Gender = 'M';
                }
                else
                    if (rdFemale.IsChecked == true || rdMale.IsChecked == false)
                {
                    patient.Gender = 'F';
                }
                patient.Address = txtAddress.Text;
                patient.PhoneNo = double.Parse(txtPhoneNo.Text);
                patient.Disease = txtDisease.Text;
                patient.DoctorId = txtDid.Text;

                int patadded = HMSBLL.HMSBLL.AddPatientBL(patient);
                RefreshPatient();
                if (patadded > 0)
                {
                    MessageBox.Show("Patient Added Succesfully", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Information);
                    ClearAll();
                }
                else
                {
                    MessageBox.Show("Patient not added");
                }
            }
            catch (HMSException.HMSException ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
        }

        private void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                string conString = "Data Source=DESKTOP-92E98T7;Initial Catalog=HMS;Integrated Security=True";

                //CREATE CONNECTION OBJECT
                SqlConnection conObj = new SqlConnection(conString);

                //SEARCHING THE CUSTOMER USING PROCEDURE
                string searchQuery = "prc_GetPatientById";


                //OPEN THE CONNECTION
                conObj.Open();

                SqlCommand cmdObj = new SqlCommand(searchQuery, conObj);


                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@PatientId", txtPid.Text);

                SqlDataReader dr;
                dr = cmdObj.ExecuteReader();
                if (dr.Read())
                {
                    txtPname.Text = dr["Name"].ToString();
                    txtAddress.Text = dr["Address"].ToString();
                    txtAge.Text = dr["Age"].ToString();
                    txtPhoneNo.Text = dr["PhoneNo"].ToString();
                    txtWeight.Text = dr["Weight"].ToString();
                    txtDisease.Text = dr["Disease"].ToString();
                    txtDid.Text = dr["DoctorId"].ToString();
                    //string gender=dr["PatientGender"].ToString();
                    //if(gender=="M")
                    //{

                    //}
                    //else
                    //{

                    //}

                }
                else
                {
                    MessageBox.Show("Patient Not Found...!", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                conObj.Close();
                //Patient searchpatient = null;
                //if (txtPid == null)
                //    MessageBox.Show("Enter Patient Id", "Hospitam Management System", MessageBoxButton.OK, MessageBoxImage.Warning);
                //string Pid = txtPid.Text;
                //searchpatient = HMSBLL.HMSBLL.GetPatientByIdBLL(Pid);
                //if (searchpatient!= null)
                //{
                //    txtPid.Text = searchpatient.PatientId;
                //    txtPid.IsEnabled = false;
                //    txtPname.Text = searchpatient.PatientName;
                //    txtAge.Text = searchpatient.Age.ToString();
                //    txtWeight.Text = searchpatient.Weight.ToString();
                //    if (rdMale.IsChecked == true || rdFemale.IsChecked == false)
                //    {
                //        searchpatient.Gender = 'M';
                //    }
                //    else
                //    if(rdMale.IsChecked == false || rdFemale.IsChecked == true)
                //    {
                //        searchpatient.Gender = 'F';
                //    }
                //    txtAddress.Text = searchpatient.Address;
                //    txtPhoneNo.Text = searchpatient.PhoneNo.ToString();
                //    txtDisease.Text = searchpatient.Disease.ToString();
                //    txtDid.Text = searchpatient.DoctorId.ToString();
                //}
                //else
                //{
                //    MessageBox.Show("Patient Id not Found","Hospital Management System",MessageBoxButton.OK,MessageBoxImage.Error);
                //}
            }
            catch (HMSException.HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDelete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string Pid = txtPid.Text;
                MessageBoxResult res = MessageBox.Show("Do you want to delete patient data", "Hospital Management System", MessageBoxButton.YesNoCancel,
                    MessageBoxImage.Warning);
                if (res == MessageBoxResult.Yes)
                {
                    int count = HMSBLL.HMSBLL.DeletePatientBL(Pid);
                    RefreshPatient();
                    ClearAll();
                    if (count > 0)
                    {
                        MessageBox.Show("Patient data deleted succesfully", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show("No patient data found with that Id", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }

                }
                else
                {
                    MainWindow display = new MainWindow();
                    display.Show();
                    this.Hide();
                }

            }
            catch (HMSException.HMSException ex)
            {
                throw ex;
            }

        }

        private void BtnUpdate_Click(object sender, RoutedEventArgs e)
        {

            Patient patient = new Patient();
            try
            {
                patient.PatientId = txtPid.Text;
                patient.PatientName = txtPname.Text;
                patient.Age = int.Parse(txtAge.Text);
                patient.Weight = int.Parse(txtWeight.Text);
                if (rdMale.IsChecked == true || rdFemale.IsChecked == false)
                {
                    patient.Gender = 'M';
                }
                else
                    if (rdFemale.IsChecked == true || rdMale.IsChecked == false)
                {
                    patient.Gender = 'F';
                }
                patient.Address = txtAddress.Text;
                patient.PhoneNo = double.Parse(txtPhoneNo.Text);
                patient.Disease = txtDisease.Text;
                patient.DoctorId = txtDid.Text;
                int result = HMSBLL.HMSBLL.UpdatePatientBL(patient);
                if (result > 0)
                {
                    MessageBox.Show("Patient Details Updated", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Information);
                    List<Patient> patients = HMSBLL.HMSBLL.GetAllPatientsBL();
                    patientGrid.ItemsSource = patients.ToList();
                }
                else
                {
                    MessageBox.Show("Patient details cannot be updtaed", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (HMSException.HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnViewPatients_Click(object sender, RoutedEventArgs e)
        {
            ClearAll();
            List<Patient> patientList = HMSBLL.HMSBLL.GetAllPatientsBL();
            patientGrid.ItemsSource = patientList.ToList();
        }

        private void BtnClear_Click(object sender, RoutedEventArgs e)
        {

            ClearAll();
        }

        private void ClearAll()
        {
            txtPid.Clear();
            txtPname.Clear();
            txtPhoneNo.Clear();
            txtAddress.Clear();
            txtAge.Clear();
            txtDisease.Clear();
            txtDid.Clear();
            txtWeight.Clear();
        }


        private void BtnAddLab_Click(object sender, RoutedEventArgs e)
        {
            Lab lab = new Lab();
            try
            {
                lab.LabId = txtLid.Text;
                lab.PatientId = txtPidL.Text;
                lab.DoctorID = txtDidL.Text;
                lab.TestDate = Convert.ToDateTime(txtDate.Text);
                lab.TestType = txtttype.Text;
                lab.PatientType = comboPtype.Text;

                int labadded = HMSBLL.HMSBLL.AddLabBL(lab);
                if (labadded > 0)
                {
                    MessageBox.Show("Lab record added succesfully", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Information);
                    ClearAllLab();
                    RefreshLabRecords();
                }
                else
                {
                    MessageBox.Show("Lab record cannot be added", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (HMSException.HMSException ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
            
        }

        private void BtnClearLab_Click(object sender, RoutedEventArgs e)
        {
            ClearAllLab();
        }

        private void ClearAllLab()
        {
            txtLid.Clear();
            txtPidL.Clear();
            txtDidL.Clear();
            txtDate.Text="";
            txtttype.Clear();
            comboPtype.Text="";
        }

        private void BtnViewLab_Click(object sender, RoutedEventArgs e)
        {
            ClearAllLab();
            List<Lab> labList = HMSBLL.HMSBLL.GetAllLabRecordsBL();
            LabRecordGrid.ItemsSource = labList.ToList();
        }

        private void RefreshLabRecords()
        {
            ClearAllLab();
            List<Lab> labList = HMSBLL.HMSBLL.GetAllLabRecordsBL();
            LabRecordGrid.ItemsSource = labList.ToList();
        }

        private void BtnSearchLab_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                string conString = "Data Source=DESKTOP-92E98T7;Initial Catalog=HMS;Integrated Security=True";

                //CREATE CONNECTION OBJECT
                SqlConnection conObj = new SqlConnection(conString);

                //SEARCHING THE CUSTOMER USING PROCEDURE
                string searchQuery = "prc_GetLabRecordById";


                //OPEN THE CONNECTION
                conObj.Open();

                SqlCommand cmdObj = new SqlCommand(searchQuery, conObj);


                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@LabId", txtLid.Text);

                SqlDataReader dr;
                dr = cmdObj.ExecuteReader();
                if (dr.Read())
                {
                    txtLid.Text = dr["LabId"].ToString();
                    txtPidL.Text = dr["PId"].ToString();
                    txtDidL.Text = dr["DoctorId"].ToString();
                    txtDate.Text = dr["TestDate"].ToString();
                    txtttype.Text = dr["TestType"].ToString();
                    comboPtype.SelectedValue = dr["PatientType"].ToString();
                }
                else
                {
                    MessageBox.Show("Lab record Not Found....!","Hospital Management System",MessageBoxButton.OK,MessageBoxImage.Error);
                }
                conObj.Close();
                
            }
            catch (HMSException.HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDeleteLab_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string Lid = txtLid.Text;
                MessageBoxResult res = MessageBox.Show("Do you want to delete Lab Record data", "Hospital Management System", MessageBoxButton.YesNoCancel,
                    MessageBoxImage.Warning);
                if (res == MessageBoxResult.Yes)
                {
                    int count = HMSBLL.HMSBLL.DeleteLabRecordBL(Lid);
                    RefreshLabRecords();
                    ClearAll();
                    if (count > 0)
                    {
                        MessageBox.Show("Lab record data deleted succesfully", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show("No Lab record data found with that Id", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }

                }
                else
                {
                    MainWindow display = new MainWindow();
                    display.Show();
                    this.Hide();
                }

            }
            catch (HMSException.HMSException ex)
            {
                throw ex;
            }
        }

        private void BtnUpdateLab_Click(object sender, RoutedEventArgs e)
        {
            Lab lab = new Lab();
            try
            {
                lab.LabId = txtLid.Text;
                lab.PatientId = txtPidL.Text;
                lab.DoctorID = txtDidL.Text;
                lab.TestDate = Convert.ToDateTime(txtDate.Text);
                lab.TestType = txtttype.Text;
                lab.PatientType = comboPtype.Text;

                int result = HMSBLL.HMSBLL.UpdateLabRecordBL(lab);
                if (result > 0)
                {
                    MessageBox.Show("Lab record Details Updated", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Information);
                    List<Lab> labs = HMSBLL.HMSBLL.GetAllLabRecordsBL();
                    LabRecordGrid.ItemsSource = labs.ToList();
                    RefreshLabRecords();
                }
                else
                {
                    MessageBox.Show("Lab record details cannot be updtaed", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (HMSException.HMSException ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
        }

        private void ClearAllBill()
        {
            txtBid.Clear();
            txtPidB.Clear();
            comboPtypeB.Text = "";
            txtDidB.Clear();
            txtDfee.Clear();
            txtRcharge.Clear();
            txtOpcharge.Clear();
            txtMfee.Clear();
            txtTdays.Clear();
            txtLfee.Clear();
            txtTamt.Clear();
        }

        private void BtnAddBill_Click(object sender, RoutedEventArgs e)
        {
            Bill bill = new Bill();
            try
            {
                bill.BillNo = txtBid.Text;
                bill.PId = txtPidB.Text;
                bill.PatientType = comboPtypeB.Text;
                bill.DoctorId =txtDidB.Text;
                bill.DoctorFees = Convert.ToDecimal(txtDfee.Text);
                bill.RoomCharge = Convert.ToDecimal(txtRcharge.Text);
                bill.OperationCharge = Convert.ToDecimal(txtOpcharge.Text);
                bill.MedicineFees = Convert.ToDecimal(txtOpcharge.Text);
                bill.TotalDays = Convert.ToDecimal(txtTdays.Text);
                bill.TotalAmount = Convert.ToDecimal(txtTamt.Text);

                int billadded = HMSBLL.HMSBLL.AddBillBL(bill);
                if (billadded > 0)
                {
                    MessageBox.Show("Bill generated succesfully", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Information);
                    ClearAllBill();
                    RefreshBills();
                }
                else
                {
                    MessageBox.Show("Bill cannot be generated successfully", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (HMSException.HMSException ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
        }

        private void BtnClearBill_Click(object sender, RoutedEventArgs e)
        {
            ClearAllBill();
        }

        private void BtnViewBill_Click(object sender, RoutedEventArgs e)
        {
            RefreshBills();
        }

        private void RefreshBills()
        {
            ClearAllBill();
            List<Bill> billsList = HMSBLL.HMSBLL.GetAllBillsBL();
            billsGrid.ItemsSource = billsList.ToList();
        }

        private void BtnSearchBill_Click(object sender, RoutedEventArgs e)
        {
            try
            {

                string conString = "Data Source=DESKTOP-92E98T7;Initial Catalog=HMS;Integrated Security=True";

                //CREATE CONNECTION OBJECT
                SqlConnection conObj = new SqlConnection(conString);

                //SEARCHING THE CUSTOMER USING PROCEDURE
                string searchQuery = "prc_GetBillById";


                //OPEN THE CONNECTION
                conObj.Open();

                SqlCommand cmdObj = new SqlCommand(searchQuery, conObj);


                cmdObj.CommandType = CommandType.StoredProcedure;
                cmdObj.Parameters.AddWithValue("@BillNo", txtBid.Text);

                SqlDataReader dr;
                dr = cmdObj.ExecuteReader();
                if (dr.Read())
                {
                    txtBid.Text = dr["BillNo"].ToString();
                    txtPidB.Text = dr["PId"].ToString();
                    comboPtypeB.SelectedItem = dr["PatientType"].ToString();
                    txtDidB.Text = dr["DoctorId"].ToString();
                    txtDfee.Text = dr["DoctorFees"].ToString();
                    txtRcharge.Text = dr["RoomCharge"].ToString();
                    txtOpcharge.Text = dr["OperationCharges"].ToString();
                    txtMfee.Text = dr["MedicineFees"].ToString();
                    txtTdays.Text = dr["TotalDays"].ToString();
                    txtLfee.Text = dr["LabFees"].ToString();
                    txtTamt.Text = dr["TotalAmount"].ToString();
                }
                else
                {
                    MessageBox.Show("Bill not Found....!", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                conObj.Close();

            }
            catch (HMSException.HMSException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void BtnDeleteBill_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string Bid = txtBid.Text;
                MessageBoxResult res = MessageBox.Show("Do you want to delete Bill data", "Hospital Management System", MessageBoxButton.YesNoCancel,
                    MessageBoxImage.Warning);
                if (res == MessageBoxResult.Yes)
                {
                    int count = HMSBLL.HMSBLL.DeleteBillBL(Bid);
                    RefreshBills();
                    ClearAll();
                    if (count > 0)
                    {
                        MessageBox.Show("Bill data deleted succesfully", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        MessageBox.Show("No Bill data found with that Id", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Error);
                    }

                }
                else
                {
                    MainWindow display = new MainWindow();
                    display.Show();
                    this.Hide();
                }

            }
            catch (HMSException.HMSException ex)
            {
                throw ex;
            }
        }

        private void BtnUpdateBill_Click(object sender, RoutedEventArgs e)
        {
            Bill bill = new Bill();
            try
            {
                bill.BillNo = txtBid.Text;
                bill.PId = txtPidB.Text;
                bill.PatientType = comboPtypeB.Text;
                bill.DoctorId = txtDidB.Text;
                bill.DoctorFees = Convert.ToDecimal(txtDfee.Text);
                bill.RoomCharge = Convert.ToDecimal(txtRcharge.Text);
                bill.OperationCharge = Convert.ToDecimal(txtOpcharge.Text);
                bill.MedicineFees = Convert.ToDecimal(txtOpcharge.Text);
                bill.TotalDays = Convert.ToDecimal(txtTdays.Text);
                bill.TotalAmount = Convert.ToDecimal(txtTamt.Text);

                int result = HMSBLL.HMSBLL.UpdateBillBL(bill);
                if (result > 0)
                {
                    MessageBox.Show("Bill Details Updated", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Information);
                    List<Bill> bills = HMSBLL.HMSBLL.GetAllBillsBL();
                    billsGrid.ItemsSource = bills.ToList();
                    RefreshBills();
                }
                else
                {
                    MessageBox.Show("Bill details cannot be updtaed", "Hospital Management System", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (HMSException.HMSException ex)
            {
                throw new HMSException.HMSException(ex.Message);
            }
        }
                
    }
}
