﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using HMSEntity;
using HMSException;

namespace HMSDAL
{
    public class PatientDAL
    {
        public static List<Patient> PatientList = new List<Patient>();
        public static string fileName = "PatientList";
        public static List<Patient> GetAllPatientsDAL()
        {
            return PatientList;
        }
        public static bool AddPatientDAL(Patient newpatient)
        {
            bool PatientAdded = false;
            try
            {
                PatientList.Add(newpatient);
                PatientAdded = true;
            }
            catch (Exception ex)
            {
                throw new HMSException.HMSExceptions(ex.Message);
            }
            return PatientAdded;
        }
        public static bool AddPatientappointmentDAL(Patient newpatient)
        {
            bool PatientAdded = false;
            try
            {
                PatientList.Add(newpatient);
                PatientAdded = true;
            }
            catch (Exception ex)
            {
                throw new HMSException.HMSExceptions(ex.Message);
            }
            return PatientAdded;
        }
        public static bool DeletePatientDAL(string deletepatientID)
        {
            bool PatientDeleted = false;
            try
            {
                for (int i = 0; i < PatientList.Count; i++)
                {
                    Patient patient = PatientList[i];
                    if (patient.PatientID == deletepatientID)
                    {
                        PatientList.RemoveAt(i);
                        PatientDeleted = true;
                        SetSerialization();
                        break;
                    }
                }

            }
            catch (Exception ex)
            {
                throw new HMSException.HMSExceptions(ex.Message);
            }
            return PatientDeleted;
        }
        public static Patient SearchPatientDAL(string searchPatientID)
        {
            Patient searchPatient = null;
            try
            {


                for (int i = 0; i < PatientList.Count; i++)
                {
                    Patient patient = PatientList[i];
                    if (patient.PatientID == searchPatientID)
                    {
                        searchPatient = PatientList[i];
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                throw new HMSException.HMSExceptions(ex.Message);
            }
            return searchPatient;
        }

        public static bool UpdatePatientDAL(Patient updatePatient)
        {
            bool patientUpdated = false;
            try
            {


                for (int i = 0; i < PatientList.Count; i++)
                {
                    Patient patient = PatientList[i];
                    if (patient.PatientID == updatePatient.PatientID)
                    {
                        PatientList[i] = updatePatient;
                        SetSerialization();
                        break;
                    }
                }

                patientUpdated = true;
            }
            catch (Exception ex)
            {
                throw new HMSException.HMSExceptions(ex.Message);
            }
            return patientUpdated;

        }


        public static void SetSerialization()
        {
            try
            {
                using (Stream file = File.Open(fileName, FileMode.Create))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(file, PatientList);
                    file.Close();
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine("File not found.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

        //Setting List if the file already exists
        public static void SetList()
        {
            DeserializeFile();
        }
        public static void DeserializeFile()
        {
            try
            {

                using (Stream file = File.Open(Directory.GetCurrentDirectory() + "\\" + fileName, FileMode.Open))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    PatientList = bf.Deserialize(file) as List<Patient>;
                    file.Close();
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            
        }
    }
}
