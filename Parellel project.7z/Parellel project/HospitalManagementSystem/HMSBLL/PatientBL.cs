﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using HMSDAL;
using HMSEntity;
using HMSException;

namespace HMSBLL
{
    public class PatientBL
    {
        public static List<Patient> GetallpatientBLL()
        {
            List<Patient> patientlist = null;
            try
            {
                patientlist = HMSDAL.PatientDAL.GetAllPatientsDAL();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return patientlist;
        }
        public static bool DeletePatientBL(string deletePatientID)
        {
            bool patientDeleted = false;
            try
            {


                if (deletePatientID != string.Empty)
                {
                    patientDeleted = HMSDAL.PatientDAL.DeletePatientDAL(deletePatientID);
                }
                else
                {
                    throw new HMSException.HMSExceptions("Invalid Patient ID");
                }
            }
            catch (HMSException.HMSExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientDeleted;
        }

        public static bool ValidatePatient(Patient patient)
        {
            StringBuilder sb = new StringBuilder();
            bool validpatient = true;
            //if (patient.PatientID == string.Empty)
            //{
            //    validpatient = false;
            //    sb.Append(Environment.NewLine + "Patient ID is required cannot be blank");

            //}
            //else if (!Regex.IsMatch(patient.PatientID, @"[0-9]+"))
            //{
            //    validpatient = false;
            //    sb.Append(Environment.NewLine + "Patient ID is invalid..");
            //}

            //if (patient.Name == string.Empty)
            //{
            //    validpatient = false;
            //    sb.Append(Environment.NewLine + "Patient name required");
            //}
            //else if (!Regex.IsMatch(patient.Name, "^^[A-Z][a-z]+"))
            //{
            //    sb.Append("Customer name should start with capital letter and it should have alphabets only");
            //    validpatient = false;
            //}

            //if (patient.Gender == string.Empty)
            //{
            //    validpatient = false;
            //    sb.Append(Environment.NewLine + "Patient Gender required");
            //}
            //else if (!Regex.IsMatch(patient.Gender, "Male|Female"))
            //{
            //    sb.Append("Gender should be Male or Female ");
            //    validpatient = false;
            //}

            ////if (patient.Age == Convert.ToInt32("")) 
            ////{
            ////    validpatient = false;
            ////    sb.Append(Environment.NewLine + "Patient Age required");
            ////}

            //if (patient.Address == string.Empty)
            //{
            //    validpatient = false;
            //    sb.Append(Environment.NewLine + "Patient Address required");
            //}

            ////if (patient.Weight == Convert.ToInt32(""))
            ////{
            ////    validpatient = false;
            ////    sb.Append(Environment.NewLine + "Patient Weight required");
            ////}

            //if (patient.PhoneNo.Length < 10)
            //{
            //    validpatient = false;
            //    sb.Append(Environment.NewLine + "Required 10 digit contact number");
            //}
            //else if (!Regex.IsMatch(patient.PhoneNo, "[7-9][0-9]{9}"))
            //{
            //    sb.Append("Phone number should start with 7 or 8 or 9 and it should have 10 numbers only\n");
            //    validpatient = false;
            //}

            if (validpatient == false)
            {
                throw new HMSException.HMSExceptions(sb.ToString());
            }
            return validpatient;
        }
        public static bool AddPatientBLL(Patient newpatient)
        {
            bool patientadded = false;
            try
            {
                if (ValidatePatient(newpatient))
                    patientadded = HMSDAL.PatientDAL.AddPatientDAL(newpatient);

            }
            catch (HMSException.HMSExceptions ex)
            {
                throw ex;
            }
            return patientadded;
        }
        public static bool AddPatientAppointmentBLL(Patient newpatient)
        {
            bool patientadded = false;
            try
            {
                if (ValidatePatient(newpatient))
                    patientadded = HMSDAL.PatientDAL.AddPatientDAL(newpatient);

            }
            catch (HMSException.HMSExceptions ex)
            {
                throw ex;
            }
            return patientadded;
        }
        public static Patient SearchPatientBL(string searchPatientID)
        {
            Patient searchPatient = null;
            try
            {
                searchPatient = HMSDAL.PatientDAL.SearchPatientDAL(searchPatientID);
            }
            catch (HMSException.HMSExceptions ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchPatient;

        }
        public static bool UpdatePatientBL(Patient updatePatient)
        {
            bool patientUpdated = false;
            try
            {
                if (ValidatePatient(updatePatient))
                {
                    HMSDAL.PatientDAL patientDAL = new HMSDAL.PatientDAL();
                    patientUpdated = HMSDAL.PatientDAL.UpdatePatientDAL(updatePatient);
                }
            }
            catch (HMSException.HMSExceptions)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return patientUpdated;
        }

        public static void SetSerialization()
        {

            if (HMSDAL.PatientDAL.PatientList != null)
            {
                HMSDAL.PatientDAL.SetSerialization();
            }
        }
        public static void setlist()
        {
            try
            {
                if (File.Exists(Directory.GetCurrentDirectory() + "\\" + HMSDAL.PatientDAL.fileName))
                    HMSDAL.PatientDAL.SetList();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
