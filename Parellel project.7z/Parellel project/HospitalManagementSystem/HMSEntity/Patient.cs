﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMSEntity
{    [Serializable]
    public class Patient
    {
        public string PatientID { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public int Age { get; set; }
        public string Address { get; set; }
        public string PhoneNo { get; set; }
        public int Weight { get; set; }
        public string Disease { get; set; }
        public string DoctorID { get; set; }
        public string DoctorName { get; set; }
        public string Dept { get; set; }
        public string LabID { get; set; }
        public DateTime TestDate { get; set; }
        public string  TestType { get; set; }
        public string PatientType { get; set; }
        public string RoomNo { get; set; }
        public DateTime AdmissionDate { get; set; }
        public DateTime DischargeDate { get; set; }
        public int AmountPerDay { get; set; }
        public DateTime TreatmentDate { get; set; }
        public string BillNo { get; set; }
        public int DoctorFee { get; set; }
        public int RoomCharge { get; set; }
        public int OperationCharges { get; set; }
        public int MedicineFee { get; set; }
        public int TotalDays { get; set; }
        public int LabFee { get; set; }
        public int TotalAmount { get; set; }

    }

}



        