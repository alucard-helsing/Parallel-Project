﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMSBLL;
using HMSEntity;
using HMSException;

namespace HMSPL
{
    class Program
    {
        private static void PrintMenu()
        {
            Console.WriteLine("\n*********Hospital Management System*********");
            Console.WriteLine("1. Add Patient");
            Console.WriteLine("2. Add Patient Appointment Details");
            Console.WriteLine("3. Delete Patient");
            Console.WriteLine("4. Get all patient details");
            Console.WriteLine("5. Search patient");
            Console.WriteLine("6. Update patient");
            Console.WriteLine("7. Serialize the patient information");
            Console.WriteLine("8. Exit");
            
        }
        public static void AddPatient()
        {
            try
            {
                Patient newpatient = new Patient();

                Console.WriteLine("Enter Patient id");
                newpatient.PatientID = Console.ReadLine();

                Console.WriteLine("Enter Patient Name");
                newpatient.Name = Console.ReadLine();

                Console.WriteLine("Enter Patient Gender");
                newpatient.Gender = Console.ReadLine();

                Console.WriteLine("Enter Patient Age");
                newpatient.Age = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Patient Weight");
                newpatient.Weight = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter phone number");
                newpatient.PhoneNo = Console.ReadLine();

                bool patientAdded = HMSBLL.PatientBL.AddPatientBLL(newpatient);
                if (patientAdded)
                {
                    Console.WriteLine("Patient added");

                }
                else Console.WriteLine("Patient not added");
            }
            catch (HMSException.HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);

            }
        }
        public static void AddPatientAppointment()
        {
            try
            {
                Patient newpatient = new Patient();
                string searchPatientID;
                Console.WriteLine("Enter PatientID to add Appointment Details");
                searchPatientID = Console.ReadLine();
                Patient searchPatient = HMSBLL.PatientBL.SearchPatientBL(searchPatientID);
                if (searchPatient != null)
                {
                    Console.WriteLine("Enter Doctor Name");
                    newpatient.DoctorName = Console.ReadLine();

                    Console.WriteLine("Enter Patient Type");
                    newpatient.PatientType = Console.ReadLine();
                    if (newpatient.PatientType == "InPatient")
                    {
                        Console.WriteLine("Enter Patient Admission Date");
                        newpatient.AdmissionDate =Convert.ToDateTime(Console.ReadLine());

                        Console.WriteLine("Enter Patient Room No");
                        newpatient.RoomNo = Console.ReadLine();

                        Console.WriteLine("Enter Patient Discharge Date");
                        newpatient.DischargeDate = Convert.ToDateTime(Console.ReadLine());
                    }
                    else if(newpatient.PatientType == "OutPatient")
                    {
                        
                        Console.WriteLine("Enter Patient Treatment Date");
                        newpatient.TreatmentDate = Convert.ToDateTime(Console.ReadLine());
                    }

                   
                }

                bool patientAdded = HMSBLL.PatientBL.AddPatientBLL(newpatient);
                if (patientAdded)
                {
                    Console.WriteLine("Patient added");

                }
                else Console.WriteLine("patient not added");
            }
            catch (HMSException.HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);

            }
        }
        public static void Deletepatient()
        {
            try
            {
                string deletePatientID;
                Console.WriteLine("Enter PatientID to Delete:");
                deletePatientID = Console.ReadLine();
                bool patientdeleted = HMSBLL.PatientBL.DeletePatientBL(deletePatientID);
                if (patientdeleted)
                    Console.WriteLine("Patient Deleted");
                else
                    Console.WriteLine("Patient not Deleted ");
            }
            catch (HMSException.HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
        private static void SearchPatientByID()
        {
            try
            {
                string searchPatientID;
                Console.WriteLine("Enter PatientID to Search:");
                searchPatientID = Console.ReadLine();
                Patient searchPatient = HMSBLL.PatientBL.SearchPatientBL(searchPatientID);
                if (searchPatient != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("PatientID\t\tName\t\tPhoneNumber");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", searchPatient.PatientID, searchPatient.Name, searchPatient.PhoneNo);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Patient Details Available");
                }

            }
            catch (HMSException.HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void UpdatePatient()
        {
            try
            {
                string updatePatientID;
                Console.WriteLine("Enter PatientID to Update Details:");
                updatePatientID = Console.ReadLine();
                Patient updatedPatient = HMSBLL.PatientBL.SearchPatientBL(updatePatientID);
                if (updatedPatient != null)
                {
                    Console.WriteLine("Update Patient Name :");
                    updatedPatient.Name = Console.ReadLine();
                    Console.WriteLine("Update PhoneNumber :");
                    updatedPatient.PhoneNo = Console.ReadLine();
                    bool patientUpdated = HMSBLL.PatientBL.UpdatePatientBL(updatedPatient);
                    if (patientUpdated)
                        Console.WriteLine("Patient Details Updated");
                    else
                        Console.WriteLine("Patient Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No Patient Details Available");
                }


            }
            catch (HMSException.HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        public static void Listallpatients()
        {
            try
            {
                List<Patient> patientlist = HMSBLL.PatientBL.GetallpatientBLL();
                if (patientlist != null && patientlist.Count > 0)
                {
                    Console.WriteLine("******************");
                    Console.WriteLine("patientid\t\tName\t\tPhone number");
                    Console.WriteLine("************");
                    foreach (Patient patient in patientlist)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", patient.PatientID, patient.Name, patient.PhoneNo);

                    }
                    Console.WriteLine("**********");
                }
                else
                {
                    Console.WriteLine("No patient Details available");
                }
            }
            catch (HMSException.HMSExceptions ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void SetSerialization()
        {
            HMSBLL.PatientBL.SetSerialization();
        }
        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            SetSerialization();
        }



        static void Main(string[] args)
        {
            HMSBLL.PatientBL.setlist();

            int choice;

            do
            {
                PrintMenu();
                Console.WriteLine(" Enter your choice");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        AddPatient();
                        break;
                    case 2:
                        AddPatientAppointment();
                        break;
                    case 3:
                        Deletepatient();
                        break;
                    case 4:
                        Listallpatients();
                        break;
                    case 5:
                        SearchPatientByID();
                        break;
                    case 6:
                        UpdatePatient();
                        break;
                    case 7:
                        SetSerialization();
                        break;
                    case 8:
                        return;


                    default:
                        SetSerialization();
                        break;
                }
            }
            while ((choice > 0) && (choice < 7));


        }
    }
}

